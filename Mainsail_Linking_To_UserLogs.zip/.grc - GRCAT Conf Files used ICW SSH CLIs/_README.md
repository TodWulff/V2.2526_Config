This directory houses GRCAT config files for use when tailing userlogs via ssh.

Tail doesn't honor ANSI color escape sequences.
Tried a number of approaches.
GRCAT seems to be the most useful in this context.

I've structured Klipper with configs that enable mainsail to emit links into the console programmatically.

Using this, I have a macro that emits links containing custom URL Protocol schemes in the form of:
tailcmpst://, tailtrace://, tailsavar://, tailgmove://, and tailstate://

Of note, the ONLY important part of the link is the SCHEME.  (SCHEME://ThisIsMerelyInformtiveBoulderdash) 

I've windows setup to process links w/ said schemes via registry edit instantiating custom URL protocols:
https://i.imgur.com/89EAU0c.png & https://i.imgur.com/bt5TiBJ.png

As, as you can see in the latter regedit screenshot, MobaXterm (MXT) is my ssh client of choice here.

The ssh client has sessions saved in which client keys are used during login for authentication.
These saved sessions are also configured to launch MXT with CLI arguments. 
An example single-line (continuation herein only for readability) CLI commands passed to the ssh client:

echo "tail -f -n100 /home/pi/printer_data/logs/user_cmpst.log | grcat /home/pi/.grc/grc_user_cmpst_log.conf" && \
tail -f -n100 /home/pi/printer_data/logs/user_cmpst.log | grcat /home/pi/.grc/grc_user_cmpst_log.conf

First command is merely an informative echo of the second command, which is the meat - tail being piped to grcat.

These links, with the URL Protocol registry mods and CLI ministrations on the client's ssh client net a nice workflow:
1)	Click on a 'Show LogTail Links" button emits a set of 5 links that contain the above schemes encoded therein,
2)	Click on one of those links to cause the client OS to instantiate a SSH Client instance and session.
3)	While not necessary, I have an instance of AHK hooked on windows messaging, looking at window creation messages and,
	if a SSH client session with a window title of specific structure, the windows size and location are adjusted to a
	predefined monitor and position thereon in a specified z-order to net as much visible space as possible

And viola, logs are opened, positioned to my debug tool display, and prettified: https://i.imgur.com/FOgMqCW.png 
using the conf files herein, all with two clicks of the mouse (one on the link, and one on the browser confirmation).
All is all this is pretty utopian.

~MHz